'use strict';

module.exports = function(Foodadded) {

};
