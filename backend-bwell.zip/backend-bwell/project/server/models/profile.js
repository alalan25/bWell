'use strict';

module.exports = function(Profile) {  
};
