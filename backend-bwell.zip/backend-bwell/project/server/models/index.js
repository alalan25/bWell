'use strict';

module.exports = function(Index) {

};
